import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { OnsenModule,OnsNavigator} from 'ngx-onsenui';
import { Location, HashLocationStrategy, LocationStrategy, PathLocationStrategy } from '@angular/common';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AnalyserComponent } from './analyser/analyser.component';
import { PaymentsComponent } from './payments/payments.component';
import { AccountsComponent } from './accounts/accounts.component';
import { appRouting } from './app.routes';
import { AppRouteConfig } from './app.router-config';
import { UtilsService } from './services/utils.service';
import { ServiceRequest } from './services/requests.service';
import { IconNamePipe } from './services/iconName.pipe';
import { routerTransition } from './services/router-animation.service';
import { WebStorageModule } from 'ngx-store';

import { ChartsModule } from 'ng2-charts';
import { ChartModule } from 'angular2-chartjs';

import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SplitContainerComponent } from './split-container/split-container.component';
import { TabberContainerComponent } from './tabber-container/tabber-container.component';
import { SplashPreloaderComponent } from './splash-preloader/splash-preloader.component';
import { SpendingComponent} from './spending/spending.component';
import {AccComponent} from './acc/acc.component';
import {OtpComponent} from './otp/otp.component';

import {PiechartComponent} from './piechart/piechart.component';
import {ChartsComponent} from './charts/charts.component';


// Page components
const pages = [TabberContainerComponent, HomeComponent, AnalyserComponent, PaymentsComponent, AccountsComponent , SpendingComponent,
  AccComponent,OtpComponent,PiechartComponent,ChartsComponent];

@NgModule({
  declarations: [
    AppComponent,
    ...pages,
    LoginComponent,
    PagenotfoundComponent,
    SplitContainerComponent,
    SplashPreloaderComponent,
    IconNamePipe
  ],
  entryComponents: [
    ...pages
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    OnsenModule,
    appRouting,
    ChartsModule,
    ChartModule,
    HttpModule,
    WebStorageModule,
    BrowserAnimationsModule
  ],
  providers: [AppRouteConfig, UtilsService, ServiceRequest , OnsNavigator ],
  exports: [IconNamePipe],
  bootstrap: [ AppComponent ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
