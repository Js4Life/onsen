import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.scss']
})
export class ChartsComponent implements OnInit {

  @Input() chartData = [];
  @Input() chartLabels = [];
  
  chartColors: Array<any> = [{
    backgroundColor: '#f0a630'
  }];
  
  // -- chart options
  barChartOptions: any = {
    scaleShowVerticalLines: false,
    maintainAspectRatio: false,
    responsive: true,
    labelLength: 10,
    legend: {
      display:false,
    },
    scales: {
      xAxes: [{
        gridLines: {
          display: false
        },
        ticks: {
          display: false
        }
      }],
      yAxes: [{
        scaleOverride : true,
        scaleStartValue : 0,
        display: true,
        gridLines: {
          display: false
        },
        ticks: {
          fontColor: '#fff',
          fontStyle: 'bold',
          fontFamily: "'Avenir Book', 'Roboto', sans-serif !important",
          callback: function(value) {
            return value.substr(0, 10)+'..';
          },
          
        }
      }]
    },
    layout: {
      padding: {
        left: 20
      }
    },
    onAnimationComplete: function () {
      console.log('onCOmplete');
      var ctx = this.chart.ctx;
      ctx.font = this.scale.font;
      ctx.fillStyle = this.scale.textColor
      ctx.textAlign = "center";
      ctx.textBaseline = "bottom";

      this.datasets.forEach(function (dataset) {
        dataset.bars.forEach(function (bar) {
            ctx.fillText(bar.value, bar.x, bar.y - 5);
        });
      });
    }
  };    
  barChartType: string = 'horizontalBar';
  barChartLegend: boolean = true;
  barChartData: any[] = [];
  barChartLabels: any[] = [];

  // events
  public chartClicked(e: any): void {
    // console.log(e);
  }

  public chartHovered(e: any): void {
    // console.log(e);
  }

  constructor() { }
  
  ngOnInit() {
    // this.randomize();
    this.barChartLabels = this.chartLabels;
    this.barChartData = this.chartData;
  }

  ngOnChanges(changes) {
    let self = this;
    self.barChartLabels = [];
    self.barChartData = [];
    setTimeout(() => {
      if(typeof changes.chartLabels !== 'undefined') self.barChartLabels = changes.chartLabels.currentValue;
      if(typeof changes.chartData !== 'undefined') self.barChartData = changes.chartData.currentValue;
    }, 100);
  }

}
