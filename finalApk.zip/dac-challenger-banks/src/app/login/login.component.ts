import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppRouteConfig } from '../app.router-config';
import { NgForm } from '@angular/forms';
import { ServiceRequest } from '../services/requests.service';
import * as ons from 'onsenui';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  target: string = '';
  formdata: any = {};
  errorMsg: any;
  loading: boolean = false;

  constructor(public router: Router, private routeConfig: AppRouteConfig, private serviceRequest: ServiceRequest) {
  }

  ngOnInit() {
    // -- for debug purposes only -- comment out before publishing the app
    this.formdata.username = 'user123';
    this.formdata.password = 'Abcde@12345';
  }

  ngAfterViewInit() {
    
  }

  loginUser() {
    var self = this;
    let jwt = sessionStorage.getItem('jwt');

    self.serviceRequest.showLoading = true;
    self.serviceRequest.getAuthorizationRequest(self.formdata.username, self.formdata.password, jwt).subscribe(data => {
      localStorage.setItem('authorization_data', JSON.stringify(data));
      localStorage.setItem('user_name', data['user-name']);
      self.serviceRequest.showLoading = false;
      self.routeConfig.gotoPage('otp');
    }, (err) => {
      console.log('err.fault.details:: ', err)
      // if(err && err.fault && err.fault.detail && err.fault.detail.errorcode == 'steps.jwt.TokenExpired') {
      if(err && err.statusText == 'Unauthorized') {
        self.serviceRequest.getAppToken().subscribe(data => {
          sessionStorage.setItem('jwt', data['apptoken']);
          self.serviceRequest.showLoading = false;
          this.loginUser();
        }, err => {
          ons.notification.alert('Error authenticating the application. Please close the app and try again.');
        });
      }
      else {
        self.serviceRequest.showLoading = false;
        ons.notification.alert('Incorrect username or password.');
      }
    });
  }
}
