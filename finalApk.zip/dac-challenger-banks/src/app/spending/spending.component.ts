import { Component, OnInit } from '@angular/core';
import {
  ViewChild,
  Params,
  OnsNavigator,
  OnsenModule,
  NgModule,
  CUSTOM_ELEMENTS_SCHEMA
} from 'ngx-onsenui';
import { ServiceRequest } from '../services/requests.service';
import { AppRouteConfig } from '../app.router-config';
import * as _ from 'underscore';
import * as moment from 'moment';
import * as ons from 'onsenui';


@Component({
  selector: 'app-spending',
  templateUrl: './spending.component.html',
  styleUrls: ['./spending.component.scss']
})
export class SpendingComponent implements OnInit {
  @ViewChild('carousel') carousel;

  accessToken:any;
  accountDetails:any;

  categoryActive = true;
  merchantActive = false;

  filterValue = moment().format('MMMM');
  filterDataValue = moment().get('month');

  filterType = 'monthly';
  filterTypes = ['monthly', 'quarterly', 'halfyearly', 'yearly'];

  spendingTransactions = [];
  // -- pie charts
  doughnutChartLabels = [];
  doughnutChartData = [];
  // -- bar chart
  barChartLabels = [];
  barChartData = [];
  
  constructor(private routeConfig: AppRouteConfig , private serviceRequest:ServiceRequest) {

  }
    
  ngOnInit() {
    var self = this;
    this.accessToken = localStorage.getItem('access_token');
    this.accessToken = (this.accessToken != null) ? JSON.parse(this.accessToken) : null;
    
    this.accountDetails = localStorage.getItem('primaryAccount');
    this.accountDetails = (this.accountDetails != null) ? JSON.parse(this.accountDetails) : null;
    
    if(this.accessToken == null || this.accountDetails == null) {
      // -- redirect user to login
      this.serviceRequest.clearAppData();
    }
    this.getSpendingData();
  }

  ngAfterViewInit() {
  }

  getSpendingData() {
    let self = this;
    let query = '';
    
    let filterTypeComponent = document.querySelector('.circle.active[data-model]');
    let filterType:any = '';
    if(filterTypeComponent) {
      filterType = filterTypeComponent.getAttribute('data-model');
    }
    else filterType = this.filterType;

    let filterValueComponent = document.querySelector('#filter__value[data-value]');
    let filterValue:any = '';
    if(filterTypeComponent) {
      filterValue = parseInt(filterValueComponent.getAttribute('data-value'));
    }
    else filterValue = this.filterDataValue;
    
    if(filterType == 'monthly') query = `month=${filterValue+1}&year=2018`;
    else if(filterType == 'quarterly') query = `quarter=Q${filterValue}&year=2018`;
    else if(filterType == 'halfyearly') query = `halfyear=H${filterValue}&year=2018`;
    else if(filterType == 'yearly') query = `halfyear=Y&year=2018`;
    
    self.serviceRequest.showLoading = true;
    self.serviceRequest.getSpendAnalyzerData(self.accessToken.access_token, self.accountDetails.AccountId, query).subscribe(spends => {
      self.serviceRequest.showLoading = false;
      if(spends && spends.error) {
        ons.notification.alert('Unable to get spendings information at the moment. Please login again.');
        setTimeout(() => {
          self.routeConfig.gotoPage('login');
        }, 1000);
      }
      else {
        self.formatSpendingData(spends);
      }
    }, error => {
      self.serviceRequest.refreshAccessToken(self.accessToken.refresh_token).subscribe(data => {
        self.serviceRequest.showLoading = false;
        data.timestamp = moment().local().format('DD-MM-YYYY HH:mm:ss');
        localStorage.setItem('access_token', JSON.stringify(data));
        self.accessToken = data;
        self.getSpendingData();
      }, error => {
        self.serviceRequest.showLoading = false;
        ons.notification.alert('Unable to get spendings information at the moment. Please login again.');
        setTimeout(() => {
          self.routeConfig.gotoPage('login');
        }, 1000);
      });
    });
  }

  formatSpendingData(spends) {
    let self = this;
    spends = spends[0];

    let spendingTransactions = [];
    // document.querySelector('.scrollable__container').innerHTML = '';
    spendingTransactions = spends && (typeof spends.Transactions !== 'undefined') ? spends.Transactions : [];
    // -- sort by ascending
    spendingTransactions = _.sortBy(spendingTransactions, 'Date');
    // -- reverse array
    spendingTransactions = spendingTransactions.reverse();
    // spendingTransactions = _.map(spendingTransactions, function(item) {
    //   item.Category = 'Clothing';
    //   return item;
    // });
    self.spendingTransactions = spendingTransactions;

    // -- generate category chart
    if(spends && typeof spends.Categories !== 'undefined') {
      self.doughnutChartLabels = [];
      self.doughnutChartData = [];
      _.each(spends.Categories, function(category:any) {
        self.doughnutChartLabels.push(category.Category);
        self.doughnutChartData.push(category.Amount);
      });
    }
    else {
      self.doughnutChartLabels = [];
      self.doughnutChartData = [];
    }

    // -- generate merchant chart
    if(spends && typeof spends.TopSpends !== 'undefined') {
      self.barChartLabels = [];
      self.barChartData = [{data: [], label: 'Top Spends'}]
      _.each(spends.TopSpends, function(merchant:any, i) {
        self.barChartLabels.push(merchant.SpendDescription);
        self.barChartData[0].data.push(merchant.Amount);
      });
    }
    else {
      self.barChartLabels = [];
      self.barChartData = [];
    }
  }

  prev() {
    this.categoryActive = true;
    this.merchantActive = false;
    this.carousel.nativeElement.prev();

    // this.resetFilters();
  }
  next() {
    this.categoryActive = false;
    this.merchantActive = true;
    this.carousel.nativeElement.next();

    // this.resetFilters();
  }

  resetFilters() {
    this.filterValue = moment().format('MMMM');
    this.filterDataValue = moment().get('month');
    this.filterType = 'monthly';
  }

  changeFilterType(e) {
    this.filterType = e.target.getAttribute('data-model');
    if(this.filterType == 'monthly') {
      this.filterValue = moment().format('MMMM');
      this.filterDataValue = moment().get('month');
    }
    else if(this.filterType == 'quarterly') {
      this.filterValue = this.getQuarterRange(moment().quarter());
      this.filterDataValue = moment().quarter();
    }
    else if(this.filterType == 'halfyearly') {
      this.filterValue = moment().month() < 6 ? 'Jan-Jun' : 'Jul-Dec';
      this.filterDataValue = moment().month() < 6 ? 1 : 2;
    }
    else if(this.filterType == 'yearly') {
      this.filterValue = '2018';
      this.filterDataValue = moment().year();
    }

    let self = this;
    setTimeout(() => {
      self.getSpendingData();
    }, 500);
  }

  changeFilterValue(e, type) {
    let currentVal = parseInt(document.querySelector('#filter__value').getAttribute('data-value'));
    let modifier = type == 'prev' ? -1 : 1;

    if(this.filterType == 'monthly') {
      if((currentVal+modifier) < 0 ||(currentVal+modifier) > moment().month()) return;
      this.filterValue = moment().month(currentVal+modifier).format('MMMM');
      this.filterDataValue = currentVal+modifier;
    }
    else if(this.filterType == 'quarterly') {
      if((currentVal+modifier) <= 0 || (currentVal+modifier) > 4) return;
      this.filterValue = this.getQuarterRange(currentVal+modifier);
      this.filterDataValue = currentVal+modifier;
    }
    else if(this.filterType == 'halfyearly') {
      if((currentVal+modifier) < 0 || (currentVal+modifier) > 2) return;
      this.filterValue = (currentVal+modifier) == 1 ? 'Jan-Jun' : 'Jul-Dec';
      this.filterDataValue = (currentVal+modifier);
    }
    else if(this.filterType == 'yearly') {
      if((currentVal+modifier) != 2018) return;
      this.filterValue = (currentVal+modifier).toString();
      this.filterDataValue = currentVal+modifier;
    }
    let self = this;
    setTimeout(() => {
      self.getSpendingData();
    }, 500);
  }

  getQuarterRange(quarter) {
    const start = moment().quarter(quarter).startOf('quarter');  
    const end = moment().quarter(quarter).endOf('quarter');
  
    return start.format('MMM')+'-'+end.format('MMM');
  }

}
