import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params, NavigationEnd } from '@angular/router';
import { ServiceRequest } from '../services/requests.service';
import { AppRouteConfig } from '../app.router-config';
import * as ons from 'onsenui';

@Component({
  selector: 'app-splash-preloader',
  templateUrl: './splash-preloader.component.html',
  styleUrls: ['./splash-preloader.component.scss']
})
export class SplashPreloaderComponent implements OnInit {
  loading:boolean = false;

  constructor(private routeConfig:AppRouteConfig, private router: Router, private requestService: ServiceRequest, activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.getAppToken();
  }

  getAppToken():void {
    var self = this;
    self.requestService.showLoading = true;

    // -- check if access token is already present
    // -- if yes redirect to home 
    // -- if no initiate the login process
    let accessToken = localStorage.getItem('access_token');
    accessToken = (accessToken != null) ? JSON.parse(accessToken) : null;
    
    // -- add check for expiry also
    if(accessToken != null) {
      self.routeConfig.gotoPage('home');
    }
    else {
      self.requestService.getAppToken().subscribe(data => {
        sessionStorage.setItem('jwt', data['apptoken']);
        self.requestService.showLoading = false;
        self.routeConfig.gotoPage('login');
      }, err => {
        ons.notification.alert('Error authenticating the application. Please close the app and try again.');
      });
    }
  }
}
