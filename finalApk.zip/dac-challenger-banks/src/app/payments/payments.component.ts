
import {
  Component,
  OnsenModule,
  NgModule,
  OnInit,
  ViewChild,
  CUSTOM_ELEMENTS_SCHEMA
} from 'ngx-onsenui';
import { ServiceRequest } from '../services/requests.service';
import { AppRouteConfig } from '../app.router-config';
import * as ons from 'onsenui';

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss']
})
export class PaymentsComponent implements OnInit {
  selectedModifier: string = 'basic';
  modifiers = [
    { value: 'basic', label: 'Basic' },
    { value: 'material', label: 'Material' },
    { value: 'underbar', label: 'Underbar' }
  ];
  @ViewChild('carousel') carousel;
  Arr:any;
  recentArr:any;
  recentBeneficiaers = {  
    "Data":{  
       "Beneficiary":[  
          {  
             "AccountId":"00000123456789",
             "NickName":"Tow Club",
             "LastTransferDate":"1501208800000",
             "Servicer":{  
                "Identification":"SC802001",
                "SchemeName":"UKSortCode"
             },
             "CreditorAccount":{  
                "Favorites":"true",
                "BeneficiaryName":"Ms Juniper",
                "BeneficiaryContact":"+91 68800-12345",
                "Identification":"888512349",
                "SchemeName":"BBAN"
             }
          },
          {  
             "AccountId":"00000123456789",
             "NickName":"payx Shop",
             "LastTransferDate":"1501200000000",
             "Servicer":{  
                "Identification":"SC802001",
                "SchemeName":"UKSortCode"
             },
             "CreditorAccount":{  
                "BeneficiaryContact":"+91 98400-12345",
                "Identification":"976512349",
                "SchemeName":"BBAN",
                "Favorites":"false",
                "BeneficiaryName":"Ms Martha"
             }
          },
          {  
             "AccountId":"00000123456789",
             "NickName":"Green Park LandLord",
             "LastTransferDate":"1501200000000",
             "Servicer":{  
                "Identification":"SC802001",
                "SchemeName":"UKSortCode"
             },
             "CreditorAccount":{  
                "Favorites":"true",
                "BeneficiaryName":"Mr Akash",
                "BeneficiaryContact":"+91 98400-99999",
                "Identification":"209976512349",
                "SchemeName":"BBAN"
             }
          },
          {  
             "AccountId":"00000123456789",
             "NickName":"PeterJ",
             "LastTransferDate":"1501200000000",
             "Servicer":{  
                "Identification":"SC802001",
                "SchemeName":"UKSortCode"
             },
             "CreditorAccount":{  
                "BeneficiaryContact":"+91 65400-12345",
                "Identification":"00345976512349",
                "SchemeName":"BBAN",
                "Favorites":"false",
                "BeneficiaryName":"Peter J"
             }
          }
       ]
    },
    "Meta":{  
 
    },
    "Links":{  
       "next":"/accounts/00000123456789/beneficiaries?pageHint=CnwKIwoQTGFzdFRyYW5zZmVyRGF0ZRIPGg0xNTAxMjAwMDAwMDAwElFqFmp+dGFjdGlsZS1kZXBvdC0yMDAyMTVyNwsSDWJlbmVmaWNpYXJpZXMiJGZhZTFkOGFkLTZlOTgtNGU0YS04NGE4LWMwM2ZmNDFiNTJiYgwYACAB"
    }
  }

  prev() {
    this.carousel.nativeElement.prev();
    window.scrollTo(0, 0);
  }
  next() {
    this.carousel.nativeElement.next();
    window.scrollTo(0, 0);
  }

  AssignLoop() {
    this.Arr = this.recentBeneficiaers.Data.Beneficiary
    this.recentArr = this.Arr.filter(obj => obj.CreditorAccount.Favorites == 'false')
  }







  accessToken;
  primaryAccount;
  primaryAccountBalance;
  recentBeneficiaries;
  allBenefeciaries;

  constructor(private routeConfig: AppRouteConfig , private serviceRequest:ServiceRequest) { }
  
  ngOnInit() {
    let self = this;
    let accessToken = localStorage.getItem('access_token');
    let primaryAccount = localStorage.getItem('primaryAccount');
    let primaryAccountBal = localStorage.getItem('primaryAccountBalance');
    if (accessToken == null || primaryAccount == null || primaryAccountBal == null) {
      ons.notification.alert('Unable to get spendings information at the moment. Please login again.');
      setTimeout(() => {
        self.routeConfig.gotoPage('');
      }, 2000);
    }

    this.accessToken = JSON.parse(accessToken);
    this.primaryAccount = JSON.parse(primaryAccount);
    this.primaryAccountBalance = JSON.parse(primaryAccountBal);

    this.getBeneficiaries();
  }

  getBeneficiaries() {
    let self = this;
    // self.serviceRequest.showLoading = true;
    // -- get recent beneficiaries
    self.serviceRequest.getBeneficiaries(self.accessToken.access_token, self.primaryAccount.AccountId, 'recent=true&limit=2').subscribe(data => {
      self.recentBeneficiaries = data.Data.Beneficiary;
      // -- get all beneficiaries
      self.serviceRequest.getBeneficiaries(self.accessToken.access_token, self.primaryAccount.AccountId, 'limit=10').subscribe(data => {
        self.serviceRequest.showLoading = false;
        self.allBenefeciaries = data.Data.Beneficiary;
      }, err => {
        self.serviceRequest.showLoading = false;
        if(err.status == 401) {
          ons.notification.alert('Unable to get beneficiaries information at the moment. Please login again.');
          setTimeout(() => {
            self.routeConfig.gotoPage('login');
          }, 1000);
        }
        else {
          ons.notification.alert('Unable to get beneficiaries information at the moment. Please try again.');
        }
      });
    }, err => {
      self.serviceRequest.showLoading = false;
      if(err.status == 401) {
        ons.notification.alert('Unable to get beneficiaries information at the moment. Please login again.');
        setTimeout(() => {
          self.routeConfig.gotoPage('login');
        }, 1000);
      }
      else {
        ons.notification.alert('Unable to get beneficiaries information at the moment. Please try again.');
      }
    });
  }

  getRandomId() {
    return Math.floor((Math.random()*6)+1);
  }

}
