import { Component, OnInit, ViewChild } from '@angular/core';
import { TabberContainerComponent } from '../tabber-container/tabber-container.component';
import { HomeComponent } from '../home/home.component';
import { UtilsService } from '../services/utils.service';
import {AccountsComponent} from '../accounts/accounts.component'

@Component({
  selector: 'app-split-container',
  templateUrl: './split-container.component.html',
  styleUrls: ['./split-container.component.scss']
})
export class SplitContainerComponent implements OnInit {
  sidePage = AccountsComponent;
  contentPage = TabberContainerComponent;
  @ViewChild('splitter') splitter;

  constructor(private utils:UtilsService) {
    this.utils.menu$.subscribe(() => this.splitter.nativeElement.side.open());
  }

  ngOnInit() {
  }

}
