import { Component,ViewChild, OnInit } from '@angular/core';
import { ServiceRequest } from '../services/requests.service';
import { AppRouteConfig } from '../app.router-config';
import * as ons from 'onsenui';

@Component({
  selector: 'app-acc',
  templateUrl: './acc.component.html',
  styleUrls: ['./acc.component.scss']
})
export class AccComponent implements OnInit {
  @ViewChild('carousel') carousel;

  // prev() {
  //   this.carousel.nativeElement.prev();
  //   window.scrollTo(0, 0);
  // }
  // next() {
  //   this.carousel.nativeElement.next();
  //   window.scrollTo(0, 0);
  // }

  primaryAccount;
  primaryAccountBalance;

  constructor(private routeConfig: AppRouteConfig , private serviceRequest:ServiceRequest) { }
  
  ngOnInit() {
    let self = this;
    let primaryAccount = localStorage.getItem('primaryAccount');
    let primaryAccountBal = localStorage.getItem('primaryAccountBalance');
    if (primaryAccount == null || primaryAccountBal == null) {
      ons.notification.alert('Unable to get spendings information at the moment. Please login again.');
      setTimeout(() => {
        self.routeConfig.gotoPage('');
      }, 2000);
    }

    this.primaryAccount = JSON.parse(primaryAccount);
    this.primaryAccountBalance = JSON.parse(primaryAccountBal);
  }

}
