import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-analyser',
  templateUrl: './analyser.component.html',
  styleUrls: ['./analyser.component.scss']
})

export class AnalyserComponent implements OnInit {

  @Input() chartsData;
  @Input() yesterday;
  @Input() weekly;
  @Input() monthly;
  @Input() defaultCurrency;

  totalYesterdayG = '0';
  totalWeeklyG = '0';
  totalMonthlyG = '0';
  defaultCurrencyG = '';
  
  // -- chart options
  barChartOptions: any = {
    scaleShowVerticalLines: false,
    maintainAspectRatio: true,
    responsive: true,
    legend: {
      display:true,
      position: 'top',
      labels: {
        fontColor: '#fff',
        fontStyle: 'bold',
        fontFamily: "'Avenir Book', 'Roboto', sans-serif !important",
      },
    },
    scales: {
      xAxes: [{
        barPercentage: 0.55,
        categoryPercentage: 1,
        gridLines: {
          display: false,
          color: '#fff'
        },
        ticks: {
          fontColor: '#fff'
        }
      }],
      yAxes: [{
        display: false,
        gridLines: {
          display: false
        },
        ticks: {
          min: 0,
          stepSize: 10
        },
      }]
    }
  };
  // -- chart colors
  chartColors: Array<any> = [
    { backgroundColor: '#20b2aa', },
    { backgroundColor: '#ff6347', },
  ];
  // -- chart meta
  barChartLabels:string [];
  barChartType: string = 'bar';
  // barChartLegend: boolean = false;
  // -- chart data
  barChartData = {};
  
  constructor() { }
  
  ngOnInit() {
    // this.randomize();
    this.barChartLabels = this.getRollingWeekDays(null);

    this.barChartData = {
      datasets: this.chartsData,
      labels: this.barChartLabels
    };
    this.totalYesterdayG = this.yesterday;
    this.totalWeeklyG = this.weekly;
    this.totalMonthlyG = this.monthly;
    this.defaultCurrencyG = this.defaultCurrency;
  }

  getRollingWeekDays(format) {
    var weekDays = [];

    var curDate = new Date();
    for (var i = 0; i < 7; ++i) {
      weekDays.push(curDate.toLocaleDateString("en-US", {
        weekday: format ? format : "short"
      }));

      curDate.setDate(curDate.getDate() - 1);
    }

    return weekDays.reverse();
  }

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }
}
