import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-piechart',
  templateUrl: './piechart.component.html',
  styleUrls: ['./piechart.component.scss']
})
export class PiechartComponent implements OnInit {
  // Doughnut
  @Input() doughnutChartLabels;
  @Input() doughnutChartData;
  doughnutChartType: string = 'doughnut';
  

  optionConfig: any = {
    maintainAspectRatio: false,
    backgroundColor: [
      "#FF6384",
      "#36A2EB",
      "#fff"
    ],
    cutoutPercentage: 80,
    title: {
      display: false,
      position: "center",
      text: 'Upcoming Meetings'
    },
    elements: {
      arc: {
        borderWidth: 0 // border line
      }
    },
    legend: {
      position: 'left',
      labels: {
        fontColor: "#fff",
        fontSize: 12,
        fontFamily: "'Avenir Book', 'Roboto', sans-serif !important",
      }
    },
    centertext: "Total Spends",
    tooltips: {
      callbacks: {
        // label: function (tooltipItem) {
        //   console.log('tooltipItem:: ', tooltipItem)
        //   return tooltipItem.yLabel;
        // }
      }
    }
  };
  // -- chart colors
  chartColors: Array<any> = [
    { backgroundColor: '#ff6347', },
    { backgroundColor: '#20b2aa', },
    { backgroundColor: '#202baa', },
  ];
  // -- chart data
  chartData = [];
  chartLabels = [];
  
  constructor() {
  }
  
  ngOnInit() {
    this.chartData = this.doughnutChartData;
    this.chartLabels = this.doughnutChartLabels;
  }

  ngOnChanges(changes) {
    if(typeof changes.doughnutChartLabels !== 'undefined') this.chartLabels = changes.doughnutChartLabels.currentValue;
    if(typeof changes.doughnutChartData !== 'undefined') this.chartData = changes.doughnutChartData.currentValue;
  }
  
  // events
  public chartClicked(e: any): void {
    // console.log(e);
  }

  public chartHovered(e: any): void {
    // console.log(e);
  }


}
