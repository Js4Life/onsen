import { Injectable } from '@angular/core';
import {Observable, Subject} from 'rxjs/Rx';

@Injectable()
export class UtilsService {

  subject = new Subject();
  get menu$(): Observable<any> {
    return this.subject.asObservable();
  }
  
  open() {
    console.log('utils::open');
    this.subject.next();
  }

  constructor() { }

}
