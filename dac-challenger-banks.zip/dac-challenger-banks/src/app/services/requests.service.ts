import { Component, OnInit, Inject, Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import 'rxjs/add/operator/map';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Observable } from "rxjs/Observable";
import * as nonce from 'nonce';
import { BehaviorSubject } from 'rxjs';
import * as ons from 'onsenui';
import * as moment from 'moment';
import { of } from 'rxjs/observable/of';

import { AppRouteConfig } from '../app.router-config';

@Injectable()
export class ServiceRequest implements OnInit {
  environment: any;
  private showLoader = new BehaviorSubject<boolean>(false);
  showLoader$ = this.showLoader.asObservable();
  public set showLoading(value: any) {
    this.showLoader.next(value);
  }
  public get showLoading():any {
    return this.showLoader.getValue()
  }

  constructor(@Inject(DOCUMENT) private document: any, private http: Http, private router: Router, private routeConfig: AppRouteConfig) {
    //Default Constructor
  }

  ngOnInit() {
    //on page load
  }

  /* Global Service call for Envionment URL set-up */
  getEnvironment() {
    this.environment = window.location.hostname;
    var data = {};
    switch (this.environment) {
      /* LocalHost Urls - Used SIT information*/
      case 'localhost':
        data = {
          env: 'dev',
          openApiEndPoint: 'https://dacopenbank.com/apis/v1.0.1/',
          accountEndPoint: 'https://dacopenbank.com/ais/open-banking/v1.0.1/',
          client_id: 'E4XHGerH7NHSCEFiX7vJNoF6A4Z4G4uo',
          accessTokenKey: 'RTRYSEdlckg3TkhTQ0VGaVg3dkpOb0Y2QTRaNEc0dW86VUUzZE5FZmdycXk4aWF6bw==',
          accessTokenSignature: 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjkwMjEwQUJBRCIsImI2NCI6ZmFsc2UsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaWF0IjoiMjAxNy0wNi0xMlQyMDowNTo1MCswMDowMCIsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaXNzIjoiQz1VSywgU1Q9RW5nbGFuZCwgTD1Mb25kb24sIE89QWNtZSBMdGQuIiwiY3JpdCI6WyJiNjQiLCJodHRwOi8vb3BlbmJhbmtpbmcub3JnLnVrL2lhdCIsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaXNzIl19..LwPFInG0hjPH2okkfcEikKYskytzd_aXipLB339W837xQEOju3ZyVezuqNKsz0ZgY5T8oX89mmZjqjxMzUeebk3K8rBEsw5QWgsNhpSZMBf2yUECp9NzdpNNEXcj4DZ1ssoyogQzvzzCooacQz6K7zJCJsHkHcdMRSmRahPLsJME6CTS_IW8FNz4C5OJVL-OIVoccNMJScdFNWHdtf5w8IM1CfXXGkh1AJUtU2x8oP1UbVPaVv4kVYzJH1siZ55yHsFh6TpKsKEsNRUXo_8x5taWSW2et5lzNqw5f3Gw7ceIdjvd1HPehILP7HleGF5llCK8-pccPZfYyyv_k-M5Zvt3-PwgK6f7yWvkMFsO1M70pdL38LK2G00ZWnX-8NFJSgb419Dx2eQuau_59R2Ek0zF8BGx3n1X0AFKGa8Tb-0f54aNBCAEx6BXIfQ0qca7hGTs27zusUzfDLWKQhRmYmOw2gKebO2xaHnyTQNbOe33i1PYaRk2mOkHn-uHISBL9Xr-AxvMyn55MG-d8uV2ckIeMvJJTTleQCJCsoLo4evjeSsyB7Gcr9Lcd3i9oWj6JBeHsZKfubGDXxDXFsvtfGoeE9HhrsLiZZ5WZAtxknT3Sy46_VLkMp764Y8SMIAmYqGaVEDHizE8x31nFlC2sasgnAlq83l1tcyH8LeALB0',
          nonce: 123456789,
          financialId: 123456789,
        };
        break;

      /* UAT Urls */
      case 'some endpoint':
        data = {
          env: 'dev',
          openApiEndPoint: 'https://digitalapicraftbank-eval-test.apigee.net/apis/v1.0.1/',
          accountEndPoint: 'https://digitalapicraftbank-eval-test.apigee.net/ais/open-banking/v1.0.1/',
          client_id: 'OAIyYyqWrAPXHvuZx5pRkkl1dPK3SG85',
          accessTokenKey: 'T0FJeVl5cVdyQVBYSHZ1Wng1cFJra2wxZFBLM1NHODU6QnZQeGVKY2NQRTFJWVZEZA==',
          accessTokenSignature: 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjkwMjEwQUJBRCIsImI2NCI6ZmFsc2UsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaWF0IjoiMjAxNy0wNi0xMlQyMDowNTo1MCswMDowMCIsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaXNzIjoiQz1VSywgU1Q9RW5nbGFuZCwgTD1Mb25kb24sIE89QWNtZSBMdGQuIiwiY3JpdCI6WyJiNjQiLCJodHRwOi8vb3BlbmJhbmtpbmcub3JnLnVrL2lhdCIsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaXNzIl19..LwPFInG0hjPH2okkfcEikKYskytzd_aXipLB339W837xQEOju3ZyVezuqNKsz0ZgY5T8oX89mmZjqjxMzUeebk3K8rBEsw5QWgsNhpSZMBf2yUECp9NzdpNNEXcj4DZ1ssoyogQzvzzCooacQz6K7zJCJsHkHcdMRSmRahPLsJME6CTS_IW8FNz4C5OJVL-OIVoccNMJScdFNWHdtf5w8IM1CfXXGkh1AJUtU2x8oP1UbVPaVv4kVYzJH1siZ55yHsFh6TpKsKEsNRUXo_8x5taWSW2et5lzNqw5f3Gw7ceIdjvd1HPehILP7HleGF5llCK8-pccPZfYyyv_k-M5Zvt3-PwgK6f7yWvkMFsO1M70pdL38LK2G00ZWnX-8NFJSgb419Dx2eQuau_59R2Ek0zF8BGx3n1X0AFKGa8Tb-0f54aNBCAEx6BXIfQ0qca7hGTs27zusUzfDLWKQhRmYmOw2gKebO2xaHnyTQNbOe33i1PYaRk2mOkHn-uHISBL9Xr-AxvMyn55MG-d8uV2ckIeMvJJTTleQCJCsoLo4evjeSsyB7Gcr9Lcd3i9oWj6JBeHsZKfubGDXxDXFsvtfGoeE9HhrsLiZZ5WZAtxknT3Sy46_VLkMp764Y8SMIAmYqGaVEDHizE8x31nFlC2sasgnAlq83l1tcyH8LeALB0',
          nonce: 123456789,
          financialId: 123456789,
        };
        break;

      /* Default url's */
      default:
        data = {
          env: 'dev',
          openApiEndPoint: 'https://digitalapicraftbank-eval-test.apigee.net/apis/v1.0.1/',
          accountEndPoint: 'https://digitalapicraftbank-eval-test.apigee.net/ais/open-banking/v1.0.1/',
          client_id: 'OAIyYyqWrAPXHvuZx5pRkkl1dPK3SG85',
          accessTokenKey: 'T0FJeVl5cVdyQVBYSHZ1Wng1cFJra2wxZFBLM1NHODU6QnZQeGVKY2NQRTFJWVZEZA==',
          accessTokenSignature: 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjkwMjEwQUJBRCIsImI2NCI6ZmFsc2UsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaWF0IjoiMjAxNy0wNi0xMlQyMDowNTo1MCswMDowMCIsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaXNzIjoiQz1VSywgU1Q9RW5nbGFuZCwgTD1Mb25kb24sIE89QWNtZSBMdGQuIiwiY3JpdCI6WyJiNjQiLCJodHRwOi8vb3BlbmJhbmtpbmcub3JnLnVrL2lhdCIsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaXNzIl19..LwPFInG0hjPH2okkfcEikKYskytzd_aXipLB339W837xQEOju3ZyVezuqNKsz0ZgY5T8oX89mmZjqjxMzUeebk3K8rBEsw5QWgsNhpSZMBf2yUECp9NzdpNNEXcj4DZ1ssoyogQzvzzCooacQz6K7zJCJsHkHcdMRSmRahPLsJME6CTS_IW8FNz4C5OJVL-OIVoccNMJScdFNWHdtf5w8IM1CfXXGkh1AJUtU2x8oP1UbVPaVv4kVYzJH1siZ55yHsFh6TpKsKEsNRUXo_8x5taWSW2et5lzNqw5f3Gw7ceIdjvd1HPehILP7HleGF5llCK8-pccPZfYyyv_k-M5Zvt3-PwgK6f7yWvkMFsO1M70pdL38LK2G00ZWnX-8NFJSgb419Dx2eQuau_59R2Ek0zF8BGx3n1X0AFKGa8Tb-0f54aNBCAEx6BXIfQ0qca7hGTs27zusUzfDLWKQhRmYmOw2gKebO2xaHnyTQNbOe33i1PYaRk2mOkHn-uHISBL9Xr-AxvMyn55MG-d8uV2ckIeMvJJTTleQCJCsoLo4evjeSsyB7Gcr9Lcd3i9oWj6JBeHsZKfubGDXxDXFsvtfGoeE9HhrsLiZZ5WZAtxknT3Sy46_VLkMp764Y8SMIAmYqGaVEDHizE8x31nFlC2sasgnAlq83l1tcyH8LeALB0',
          nonce: 123456789,
          financialId: 123456789,
        };
    }
    return data;
  }

  /* Access Token Service Call */
  getAppToken() {
    let envVar = this.getEnvironment();
    let headers = new Headers({
      // -- hardcoded right now, will need to add it to env configuration
      "authorization": "Basic " + envVar['accessTokenKey'],
      "content-type": "application/x-www-form-urlencoded",
    });
    let options = new RequestOptions({ headers: headers });
    let reqBody = `scope=accounts&grant_type=client_credentials&x-fapi-financial-id=${envVar['financialId']}&x-jws-signature=${envVar['accessTokenSignature']}&client_id=${envVar['client_id']}&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%2F&nonce=${envVar['nonce']}&state=af0ifjsldkj`;
    return this.http.post(envVar['openApiEndPoint'] + 'appToken', reqBody, options).map((res: Response) => { return res.json(); });
  }

  getAuthorizationRequest(username, password, jwt) {
    let envVar = this.getEnvironment();
    let encodedUserCredentials = btoa(username + ':' + password);
    let headers = new Headers({
      "authorization": "Basic "+encodedUserCredentials,
      "content-type": "application/x-www-form-urlencoded",
    });
    let options = new RequestOptions({headers: headers});
    // let reqBody = 'client_id=OAIyYyqWrAPXHvuZx5pRkkl1dPK3SG85&redirect_uri=http%3A%2F%2Flocalhost%2F&response_type=code&state=af0ifjsldkj&scope=openid+accounts&nonce=1753456778&request=' + jwt;
    let reqBody = `client_id=${envVar['client_id']}&redirect_uri=http%3A%2F%2Flocalhost%2F&response_type=code&state=af0ifjsldkj&scope=openid+accounts&nonce=${envVar['nonce']}&request=${jwt}`;

    return this.http.post(envVar['openApiEndPoint'] + 'oauth/authorize', reqBody, options).map((res: Response) => {
      return res.json();
    });
  }

  // 3rd API
  getAccesstoken(codeVal, mobile, token, otp) {
    let envVar = this.getEnvironment();
    let headers = new Headers({
      "authorization": "Basic " +envVar['accessTokenKey'],
      "content-type":"application/x-www-form-urlencoded"
    });

    let options = new RequestOptions({headers:headers});
    let reqBody = `scope=accounts&grant_type=authorization_code&client_id=${envVar['client_id']}&redirect_uri=http%3A%2F%2Flocalhost%2F&otpcode=${otp}&code=${codeVal}&mobilenumber=${mobile}&x-token_text=${token}`;

    return this.http.post(envVar['openApiEndPoint'] + 'oauth/token', reqBody, options).map((res: Response) => {
      return res.json();
    });

  }

  // -- refresh access token using the refresh token.
  refreshAccessToken(refToken) {
    let envVar = this.getEnvironment();
    let headers = new Headers({
      "authorization":"Basic " + envVar['accessTokenKey'],
      "content-type":"application/x-www-form-urlencoded"
    });
    let options = new RequestOptions({headers:headers});
    let reqBody = 'refresh_token='+refToken+'&grant_type=refresh_token';

    return this.http.post(envVar['openApiEndPoint'] + 'oauth/token', reqBody, options).map((res:Response) => {
      return res.json();
    });
  }

  // Get Account Service Requests
  getAccountDetails(accessTkn) {
    let self = this;
    let envVar = this.getEnvironment();
    let headers = new Headers({
      "x-fapi-financial-id":123456789,
      "Authorization":"Bearer "+accessTkn
    });

    let options = new RequestOptions({headers: headers});
    return this.http.get(envVar['accountEndPoint'] + 'accounts', options).map((res: Response) => {
      var allAccountsData = res.json();
      if(allAccountsData['Data']['Account'] && allAccountsData['Data']['Account'].length == 0) {
        self.showLoading = false;
        ons.notification.alert('No account linked with this account. Please close the app and try again with other user.');  
      }
      else {
        var primaryAccount = allAccountsData['Data']['Account'][0];
        localStorage.setItem('allAccountsData', JSON.stringify(allAccountsData));
        localStorage.setItem('primaryAccount', JSON.stringify(primaryAccount));
        const accountId = primaryAccount.AccountId;

        return accountId;
      } 
    });
  }

  getAccountDetailsById(accessTkn, id) {
    let envVar = this.getEnvironment();
    let headers = new Headers({
      "x-fapi-financial-id":123456789,
      "Authorization":"Bearer "+accessTkn
    });

    let options = new RequestOptions({headers:headers});
    return this.http.get(envVar['accountEndPoint'] + 'accounts/' + id, options).map((res: Response) => {
      let primaryAccountDetails = res.json();
      primaryAccountDetails = primaryAccountDetails.Data;
      localStorage.setItem('primaryAccountDetails', JSON.stringify(primaryAccountDetails));
      return res.json();
    });
  }

  getAccountTranscation(accessTkn, accountId, count, dateRange) {
    let envVar = this.getEnvironment();
    let headers = new Headers({
      "x-fapi-financial-id":123456789,
      "Authorization":"Bearer "+accessTkn
    });
    let options = new RequestOptions({headers:headers});

    // if(count == null) count = 10;
    if(dateRange == null) dateRange = {
      start: moment().startOf('month').format('YYYY-MM-DD'),
      end: moment().endOf('month').format('YYYY-MM-DD')
    };

    return this.http.get(`${envVar['accountEndPoint']}accounts/${accountId}/transactions?${count != null ? 'limit='+count+'&' : ''}${dateRange != null ? 'fromBookingDateTime='+dateRange.start+'&toBookingDateTime='+dateRange.end : ''}`, options).map((res: Response) => {
      let primaryAccountTransactions = res.json();
      primaryAccountTransactions = primaryAccountTransactions.Data;
      localStorage.setItem('primaryAccountTransactions', JSON.stringify(primaryAccountTransactions));
      return res.json();
    });
  }

  getAccountBalances(accessTkn, accountId) {
    let envVar = this.getEnvironment();
    let headers = new Headers({
      "x-fapi-financial-id":123456789,
      "Authorization":"Bearer "+accessTkn
    });
    let options = new RequestOptions({headers:headers});
    return this.http.get(envVar['accountEndPoint'] + 'accounts/' + accountId + '/balances', options).map((res: Response) => {
      let primaryAccountBalance = res.json();
      primaryAccountBalance = primaryAccountBalance.Data.Balance[0];
      localStorage.setItem('primaryAccountBalance', JSON.stringify(primaryAccountBalance));
      return res.json();
    });
  }

  getSpendAnalyzerData(accessTkn, accountId, query) {
    console.log('query:: ', query)
    if(query == '') return of({error: 'Query cannot be empty.'});
    let spendsData:any = localStorage.getItem('spendsData');
    if(spendsData !== null) {
      spendsData = JSON.parse(spendsData);
      if(spendsData && spendsData[query] != undefined) {
        // -- data already present in local storage, serve from there
        return of(spendsData[query]);
      }
    }
    else spendsData = {};

    let envVar = this.getEnvironment();
    let headers = new Headers({
      "x-fapi-financial-id":123456789,
      "Authorization":"Bearer "+accessTkn
    });
    let options = new RequestOptions({headers:headers});
    return this.http.get(envVar['accountEndPoint'] + 'accounts/' + accountId + '/spends?'+query, options).map((res: Response) => {
      let spendData = res.json();
      spendData = spendData.Data.Spend;
      spendsData[query] = spendData;
      localStorage.setItem('spendsData', JSON.stringify(spendsData));
      return spendData;
    });
  }

  clearAppData() {
    localStorage.clear();
    sessionStorage.clear();
    this.routeConfig.gotoPage('login');
  }
}
