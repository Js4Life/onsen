import { Component, OnInit } from '@angular/core';
import { UtilsService } from '../services/utils.service';
import { ServiceRequest } from '../services/requests.service';
import { AppRouteConfig } from '../app.router-config';

import { HomeComponent } from '../home/home.component';

import { AnalyserComponent } from '../analyser/analyser.component';
import { PaymentsComponent } from '../payments/payments.component';
import { SpendingComponent} from '../spending/spending.component';
import { AccComponent } from '../acc/acc.component';

@Component({
  selector: 'app-tabber-container',
  templateUrl: './tabber-container.component.html',
  styleUrls: ['./tabber-container.component.scss']
})
export class TabberContainerComponent implements OnInit {

  home = HomeComponent;
  spending = SpendingComponent;
  accounts= AccComponent;
  payments = PaymentsComponent;

  currentTab = 'Home';

  constructor(private utils:UtilsService, private routeConfig: AppRouteConfig , private serviceRequest:ServiceRequest) {
  }

  ngOnInit() {
  }

  openMenu() {
    this.utils.open();
  }

  onTabChange(e) {
    this.currentTab = e.tabItem && e.tabItem.getAttribute('label');
  }

  logout() {
    console.log('logout');
    this.serviceRequest.clearAppData();
  }

}
