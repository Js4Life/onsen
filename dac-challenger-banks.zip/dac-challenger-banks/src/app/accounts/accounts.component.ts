import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit {
  footerArray = [
    {
      imgPath: "md-home",
      title: "Home"
    },
    {
      imgPath: "md-accounts-alt",
      title: "Spending"
    },
    {
      imgPath: "md-chart-donut",
      title: "Account"
    },
    {
      imgPath: "md-money-box",
      title: "Payments"
    },
    {
      imgPath: "md-view-list",
      title: "More"
    }
  ];


  NavigOpt = ['Home','About','Help','Logout'];

  constructor() { }

  ngOnInit() {
  }

}
