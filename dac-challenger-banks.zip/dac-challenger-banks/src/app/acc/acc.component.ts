import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acc',
  templateUrl: './acc.component.html',
  styleUrls: ['./acc.component.scss']
})
export class AccComponent implements OnInit {

  NavigOpt = ['Home','About','Help','Logout'];

  constructor() { }

  ngOnInit() {
  }

}
