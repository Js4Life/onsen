import { Component, OnInit } from '@angular/core';
import { ServiceRequest } from '../services/requests.service';
import { AppRouteConfig } from '../app.router-config';
import * as _ from 'underscore';
import * as moment from 'moment';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {
  loading : boolean = false;
  show: boolean = false;
  allAccDetails: any;
  accId:any;
  TranscationArr:any;
  merchantArr:any;

  primaryAccount;
  primaryAccountBalance;
  recentTransactions;
  defaultCurrency:string = 'GBP';
  primaryAccountId:string = '-';
  transactionChartsData = [];
  totalYesterday = 0;
  totalWeekly = 0;
  totalMonthly = 0;

  availableBalances = [{
    price: 0,
    label: "Available Balance"
  }, {
    price: 0,
    label: "Spent Today"
  }];

  constructor(private routeConfig: AppRouteConfig , private serviceRequest:ServiceRequest) {
    
  }
  // access
  ngOnInit() {
    console.log('ngOnInit')
    this.setupAccountTransactions();
  }
  // access
  ngOnViewInit() {
    console.log('ngOnViewInit')
    this.setupAccountTransactions();
  }

  setupAccountTransactions() {
    var self = this;

    self.serviceRequest.showLoading = false;
    self.primaryAccount = localStorage.getItem('primaryAccount');
    if(self.primaryAccount == null) {
      return self.routeConfig.gotoPage('home');
    }
    
    self.primaryAccount = JSON.parse(self.primaryAccount);
    self.primaryAccountId = self.primaryAccount.AccountId;
    
    self.primaryAccountBalance = JSON.parse(localStorage.getItem('primaryAccountBalance'));
    self.availableBalances[0].price = self.primaryAccountBalance.Amount.Amount;
    self.defaultCurrency = self.primaryAccountBalance.Amount.Currency;

    // -- calculate amount spent today
    let recentTransactionsObj = JSON.parse(localStorage.getItem('primaryAccountTransactions'));
    let recentTransactions = recentTransactionsObj.Transaction;
    // -- sort by ascending
    recentTransactions = _.sortBy(recentTransactions, 'BookingDateTime');
    // -- reverse array
    recentTransactions = recentTransactions.reverse();
    // -- slice into 5 transations only
    self.recentTransactions = recentTransactions.slice(0, 5);

    // -- calculate yesterday, week and totalMonthly transations
    let today = moment().endOf('day').format('YYYY-MM-DD'),
        yesterday = moment().subtract(1, 'days').format('YYYY-MM-DD'),
        weekStart = moment().startOf('week').format('YYYY-MM-DD'),
        weekEnd = moment().endOf('week').format('YYYY-MM-DD');
    _.each(recentTransactions, function(transation:any) {
      // -- sum today
      if(moment(transation['BookingDateTime']).isSame(today, 'day')) self.availableBalances[1].price += parseFloat(transation.Amount.Amount);
      // -- sum yesterday
      if(moment(transation['BookingDateTime']).isSame(yesterday, 'day')) self.totalYesterday += parseFloat(transation.Amount.Amount);
      // -- sum week
      if(moment(transation['BookingDateTime']).isBetween(moment(weekStart).startOf('day'), moment(weekEnd).endOf('day'))) self.totalWeekly += parseFloat(transation.Amount.Amount);
      // -- sum month
      if(moment(transation['BookingDateTime']).isSame(today, 'month')) self.totalMonthly += parseFloat(transation.Amount.Amount);
    });

    // -- generate charts data
    let barChartData = [
      {data: [0,0,0,0,0,0,0], label: 'Credit'},
      {data: [0,0,0,0,0,0,0], label: 'Debit'}
    ];

    let weekdays = this.getRollingWeekDays(null);
    _.each(recentTransactionsObj.Summary, function(transation:any) {
      var day = moment(transation.Date).format('ddd');
      var index = weekdays.indexOf(day);
      if(index != undefined) {
        barChartData[0].data[index] = transation.TotalCredits;
        barChartData[1].data[index] = transation.TotalDebits;
      }
    });
    this.transactionChartsData = barChartData;
  }

  getRollingWeekDays(format) {
    var weekDays = [];

    var curDate = new Date();
    for (var i = 0; i < 7; ++i) {
      weekDays.push(curDate.toLocaleDateString("en-US", {
        weekday: format ? format : "short"
      }));

      curDate.setDate(curDate.getDate() - 1);
    }

    return weekDays.reverse();
  }

}
