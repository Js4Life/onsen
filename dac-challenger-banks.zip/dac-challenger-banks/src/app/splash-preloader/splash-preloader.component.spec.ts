import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SplashPreloaderComponent } from './splash-preloader.component';

describe('SplashPreloaderComponent', () => {
  let component: SplashPreloaderComponent;
  let fixture: ComponentFixture<SplashPreloaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SplashPreloaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplashPreloaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
