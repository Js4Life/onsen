import { Component, ViewChild ,OnInit} from '@angular/core';
import { Router, ActivatedRoute, Params, NavigationEnd } from '@angular/router';
import { ServiceRequest } from './services/requests.service';
import { AppRouteConfig } from './app.router-config';
import { Subscription } from 'rxjs';
import { routerTransition } from './services/router-animation.service';

@Component({
  selector: 'app-root',
  animations: [routerTransition],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  loading:boolean = false;
  showLoading: Subscription;

  constructor(private goto:AppRouteConfig, private router: Router, private serviceRequest: ServiceRequest,activatedRoute: ActivatedRoute) { }
  
  ngOnInit() {
    this.showLoading = this.serviceRequest.showLoader$.subscribe(show => { this.loading = show; });
  }

  ngOnDestroy() {
    this.showLoading.unsubscribe();
  }

  getState(outlet) {
    // console.log('outlet.activatedRouteData.state:: ', outlet.activatedRouteData.state)
    return outlet.isActivated ? outlet.activatedRoute : '';
  }

  preloaderClickBlock() {
    
  }
}
