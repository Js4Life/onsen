import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SplashPreloaderComponent } from './splash-preloader/splash-preloader.component';
import { LoginComponent } from './login/login.component';
import { SplitContainerComponent } from './split-container/split-container.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { OtpComponent } from './otp/otp.component';

import { AppComponent } from './app.component';

const appRoutes: Routes = [
  { path: '', component: SplashPreloaderComponent },
  { path: 'login', component: LoginComponent },
  { path: 'otp', component: OtpComponent },
  { path: 'home', component: SplitContainerComponent },
  { path: '**', component: PagenotfoundComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      {
        useHash: true,
        // enableTracing: true, // <-- debugging purposes only
      }
    )
  ],
  exports: [
    RouterModule
  ]
})

export class appRouting { }
