import { Component, OnInit } from '@angular/core';
import { ServiceRequest } from '../services/requests.service';
import { AppRouteConfig } from '../app.router-config';
import * as ons from 'onsenui';
import * as moment from 'moment';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.scss']
})
export class OtpComponent implements OnInit {
  loading: boolean = false;
  otp:string = '';
  accessTokenData;
  
  constructor(private serviceRequest: ServiceRequest, private routeConfig: AppRouteConfig) { }

  ngOnInit() { }
  
  verifyOTPRequest() {
    var self = this;
    var authorization_data = (localStorage.getItem('authorization_data') != null) ? JSON.parse(localStorage.getItem('authorization_data')) : null;
    if(authorization_data == null) {
      self.routeConfig.gotoPage('');
      ons.notification.alert('Cannot process this request. Please try agian.');
    }
    else {
      const code = authorization_data['authorization-code'];
      const reqId = authorization_data['otpRequestId'];
      const mobile = authorization_data['mfa-mobile-number'];

      if(this.otp == '' || this.otp.length < 6) {
        ons.notification.alert('Enter correct OTP before proceeding.');
      }
      else {
        self.serviceRequest.showLoading = true;
        self.serviceRequest.getAccesstoken(code, mobile, reqId, this.otp).subscribe(data => {
          data.timestamp = moment().local().format('DD-MM-YYYY HH:mm:ss');
          self.serviceRequest.showLoading = false;
          localStorage.setItem('access_token', JSON.stringify(data));
          self.accessTokenData = data;
          self.getAccountDetails();
        }, (err) => {
          console.log('error: ', err);
        });
      }

    }
  }

  regenerateOTPRequest() {
    var getRefreshToken = localStorage.getItem('refresh');
    this.serviceRequest.refreshAccessToken(getRefreshToken).subscribe(data => {
      
    }, (err) => {
      console.log('error: ', err);
    });
  }

  getAccountDetails() {
    var self = this;
    self.serviceRequest.showLoading = true;

    var accessToken = self.accessTokenData.access_token;
    self.serviceRequest.getAccountDetails(accessToken).subscribe(accountId => {
      self.serviceRequest.showLoading = false;
      self.getPrimaryBalances(accountId);
    }, err => {
      self.serviceRequest.showLoading = false;
      ons.notification.alert('Unable to get account information at the moment. Please close the app and try again.');
    });
  }

  getPrimaryAccountDetails(accountId) {
    var self = this;

    var accessToken = self.accessTokenData.access_token;
    self.serviceRequest.showLoading = true;
    self.serviceRequest.getAccountDetailsById(accessToken, accountId).subscribe(accountTransactions => {
      self.serviceRequest.showLoading = false;
      self.getAccountTranscation(accountId, 5);
    }, err => {
      self.serviceRequest.showLoading = false;
      ons.notification.alert('Unable to get account information at the moment. Please close the app and try again.');
    });
  }

  getPrimaryBalances(accountId) {
    var self = this;

    var accessToken = self.accessTokenData.access_token;
    self.serviceRequest.showLoading = true;
    self.serviceRequest.getAccountBalances(accessToken, accountId).subscribe(accountTransactions => {
      self.serviceRequest.showLoading = false;
      self.getAccountTranscation(accountId, 5);
    }, err => {
      self.serviceRequest.showLoading = false;
      ons.notification.alert('Unable to get account information at the moment. Please close the app and try again.');
    });
  }

  getAccountTranscation(accountId, count) {
    var self = this;
    var dateStart = moment().startOf('month').format('YYYY-MM-DD');
    var dateEnd = moment().endOf('month').format('YYYY-MM-DD');
    var accessToken = self.accessTokenData.access_token;
    self.serviceRequest.showLoading = true;
    self.serviceRequest.getAccountTranscation(accessToken, accountId, count, {start: dateStart, end: dateEnd}).subscribe(accountTransactions => {
      self.serviceRequest.showLoading = false;
      self.routeConfig.gotoPage('home');
    }, err => {
      self.serviceRequest.showLoading = false;
      ons.notification.alert('Unable to get account information at the moment. Please close the app and try again.');
    });
  }
}
